1) Copy fftw-3.3-libs-visual-studio-2010.zip to fftw-3.3 folder.
2) unzip the zip file to create a folder fftw-3.3-libs.
3) start visual studio 2010 and load the fftw-3.3-libs.sln

The solution supports building various combinations of 32 bit and 64 bit version of the fftw-3.3 library.

